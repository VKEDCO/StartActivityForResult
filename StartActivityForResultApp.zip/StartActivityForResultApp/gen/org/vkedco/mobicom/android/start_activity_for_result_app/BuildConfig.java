/** Automatically generated file. DO NOT MODIFY */
package org.vkedco.mobicom.android.start_activity_for_result_app;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}