package org.vkedco.mobicom.android.start_activity_for_result_app;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class StartActivityForResultParentAct extends Activity 
implements OnClickListener
{
	
	// children's names, aka request codes
	final static int FIBO_REQUEST_CODE  = 1;
	final static int PRIME_REQUEST_CODE = 2;
	
	// children's actions for implicit intents
	final static String COMPUTE_FIBO_ACTION = "org.vkedco.android.mobicom.fibonacci";
	final static String COMPUTE_PRIME_ACTION = "org.vkedco.android.mobicom.primes";
	
	EditText mEdTxtFibocn = null;
	EditText mEdTxtPrime  = null;
	
	Button mBtnExplFibocn  = null;
	Button mBtnExplPrime = null;
	Button mBtnImplFibocn  = null;
	Button mBtnImplPrime = null;
	
	Resources mRes = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_start_activity_for_result_main_layout);
		
		mEdTxtFibocn = (EditText) this.findViewById(R.id.edTxtFibocn);
		mEdTxtPrime  = (EditText) this.findViewById(R.id.edTxtPrime);
		
		mBtnExplFibocn  = (Button) this.findViewById(R.id.btnExplFibcn);
		mBtnExplPrime = (Button) this.findViewById(R.id.btnExplPrime);
		mBtnImplFibocn  = (Button) this.findViewById(R.id.btnImplFibcn);
		mBtnImplPrime = (Button) this.findViewById(R.id.btnImplPrime);
		
		mBtnExplFibocn.setOnClickListener(this);
		mBtnExplPrime.setOnClickListener(this);
		mBtnImplFibocn.setOnClickListener(this);
		mBtnImplPrime.setOnClickListener(this);
		
		mRes = getResources();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.start_activity_for_result_main, menu);
		return true;
	}
	
	@Override
	public void onClick(View v) {
		Button clickedButton = (Button) v;
		int nth;
		switch ( clickedButton.getId() ) {
		case R.id.btnExplFibcn:
			nth = Integer.parseInt(mEdTxtFibocn.getText().toString());
			Intent explFiboIntent = new Intent(this, FibonacciNumbersChildAct.class);
			explFiboIntent
				.putExtra(mRes.getString(R.string.fibo_request_key), nth);
			startActivityForResult(explFiboIntent, StartActivityForResultParentAct.FIBO_REQUEST_CODE); 
			return;
		case R.id.btnExplPrime:
			try { 
				nth = Integer.parseInt(this.mEdTxtPrime.getText().toString());
				Intent explPrimeIntent = new Intent(this, PrimeNumbersChildAct.class);
				explPrimeIntent.putExtra(mRes.getString(R.string.prime_request_key), nth);
				startActivityForResult(explPrimeIntent, StartActivityForResultParentAct.PRIME_REQUEST_CODE);
				return;
			} catch ( Exception ex ) {}
			return;
		case R.id.btnImplFibcn:
			nth = Integer.parseInt(mEdTxtFibocn.getText().toString());
			Intent implFiboIntent = new Intent(StartActivityForResultParentAct.COMPUTE_FIBO_ACTION);
			implFiboIntent.putExtra(mRes.getString(R.string.fibo_request_key), nth);
			startActivityForResult(implFiboIntent, StartActivityForResultParentAct.FIBO_REQUEST_CODE);
			return;
		case R.id.btnImplPrime:
			// TODO
			return;
		}
	}
	
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent returnedData) {
		super.onActivityResult(requestCode, resultCode, returnedData);
		
		switch ( requestCode ) {
		case StartActivityForResultParentAct.FIBO_REQUEST_CODE:
			if ( resultCode == Activity.RESULT_OK ) {
				if ( returnedData.hasExtra(mRes.getString(R.string.fibo_result_key)) ) {
					Toast.makeText(this, 
							"Fibo = " + 
									returnedData
										.getIntExtra(mRes.getString(R.string.fibo_result_key), -1),
							Toast.LENGTH_LONG).show();
				}
				else {
					Toast.makeText(this, 
							"Fibo Computation Failure",
							Toast.LENGTH_LONG).show();
				}
			}
			return;
		case StartActivityForResultParentAct.PRIME_REQUEST_CODE:
			if ( resultCode == Activity.RESULT_OK ) {
				if ( returnedData.hasExtra(mRes.getString(R.string.prime_result_key))) {
					int nth_prime = returnedData.getIntExtra(mRes.getString(R.string.prime_result_key), -1);
					Toast.makeText(this, "Prime = " + nth_prime, Toast.LENGTH_LONG).show();
				}
				else {
					Toast.makeText(this, "Prime Computation Failure", Toast.LENGTH_LONG).show();
				}
			}
			return;
		}
	}
	

}
