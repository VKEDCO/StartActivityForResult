package org.vkedco.mobicom.android.start_activity_for_result_app;

import android.app.Activity;
import android.os.Bundle;

public class PrimeNumbersChildAct extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		//setContentView(R.layout.activity_start_activity_for_result_main_layout);
	}
	
	private static int nth_prime(int n) {
		if ( n > 20 ) {
			return -1;
		}
		if ( n == 0 ) return 2;
		if ( n == 1 ) return 3;
		int prime_count = 1;
		int curr_num = 4;
		while ( 1 == 1 ) {
			if ( is_prime(curr_num) ) {
				prime_count++;
			}
			if ( prime_count == n ) {
				return curr_num;
			}
			curr_num++;
		}
	}
	
	private static boolean is_prime(int x) {
		for(int div = 2; div <= (int)(Math.sqrt(x))+1; div++)
			if ( x % div == 0 )
				return false;
		return true;
	}

}
